const players = ["Player 1", "Player 2", "Player 3", "Player 4"];
let scores = [0, 0, 0, 0];

function rollDice() {
    return Math.floor(Math.random() * 6) + 1; // Random number between 1-6
}

function playRound() {
    let results = players.map((player, index) => {
        let diceRoll = rollDice();
        scores[index] += diceRoll; // Add to player's total score
        document.querySelector(`#player${index+1} .score`).textContent = scores[index];
        return { player, diceRoll };
    });

    results.sort((a, b) => b.diceRoll - a.diceRoll); // Sort by highest roll
    displayResults(results);
    updateLeaderboard();
}

function displayResults(results) {
    let resultText = results.map(res => `${res.player} rolled: ${res.diceRoll}`).join("<br>");
    document.getElementById("results").innerHTML = `<b>${resultText}</b>`;
}

function updateLeaderboard() {
    let leaderboard = players.map((player, index) => {
        return { player, score: scores[index] };
    });

    leaderboard.sort((a, b) => b.score - a.score); // Sort by highest total score

    let leaderboardHTML = leaderboard.map(entry => `<li>${entry.player}: ${entry.score}</li>`).join("");
    document.getElementById("leaderboard").innerHTML = leaderboardHTML;
}

// Run a round when button is clicked
document.getElementById("rollButton").addEventListener("click", playRound);
